// FREIVORA · service worker: deixa o app abrir mesmo sem internet.
// Os dados do usuário ficam no aparelho; este arquivo guarda só a "casca" do app.
const V = 'freivora-v1';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png', 'apple-touch-icon.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== V).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.origin !== location.origin) return; // cotações, clima e Open Finance sempre vão direto à internet
  if (r.mode === 'navigate') {
    // abre a versão mais nova quando há internet; sem internet, usa a guardada
    e.respondWith(
      fetch(r).then(x => { const c = x.clone(); caches.open(V).then(h => h.put('index.html', c)); return x; })
        .catch(() => caches.match('index.html'))
    );
    return;
  }
  e.respondWith(
    caches.match(r).then(m => m || fetch(r).then(x => { const c = x.clone(); caches.open(V).then(h => h.put(r, c)); return x; }))
  );
});
